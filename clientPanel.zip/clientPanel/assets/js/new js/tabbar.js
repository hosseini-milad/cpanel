const IpInput =document.getElementById("ip-input")
const ComInput =document.getElementById("com-input")
const RtnInput =document.getElementById("rtn-input")
const CanInput =document.getElementById("can-input")

const IpPage =document.querySelector(".ip-page")
const ComPage =document.querySelector(".com-page")
const RtnPage =document.querySelector(".rtn-page")
const CanPage =document.querySelector(".can-page")

IpInput.addEventListener("click" , () => {
  IpPage.classList.add("display-page")
  ComPage.classList.remove("display-page")
  RtnPage.classList.remove("display-page")
  CanPage.classList.remove("display-page")
})
ComInput.addEventListener("click" , () => {
  IpPage.classList.remove("display-page")
  ComPage.classList.add("display-page")
  RtnPage.classList.remove("display-page")
  CanPage.classList.remove("display-page")
})
RtnInput.addEventListener("click" , () => {
  IpPage.classList.remove("display-page")
  ComPage.classList.remove("display-page")
  RtnPage.classList.add("display-page")
  CanPage.classList.remove("display-page")
})
CanInput.addEventListener("click" , () => {
  IpPage.classList.remove("display-page")
  ComPage.classList.remove("display-page")
  RtnPage.classList.remove("display-page")
  CanPage.classList.add("display-page")
})
