// Delete Modal Elements
const OpenDelModalBtn = document.querySelector(".d-m-btn")
const CloseDelModalBtnDel = document.querySelector(".del-btn")
const CloseDelModalBtnCan = document.querySelector(".cancel-btn")
const DelModal = document.querySelector(".modal-backdrop")
const CheckModal = document.getElementById("sure")
const toggleDelModal = () => {
  DelModal.classList.toggle("show-modal");
};
// OPEN Delete MODAL BOX
OpenDelModalBtn.addEventListener("click", () => {
  toggleDelModal();
});

// CLOSE Delete MODAL BOX
CloseDelModalBtnCan.addEventListener("click", () => {
  toggleDelModal();
});

// CLOSE Delete MODAL BOX WHEN Checked
CloseDelModalBtnDel.addEventListener("click", (e) => {
  const currentElement = e.target;

  if (CheckModal.checked) {
    toggleDelModal();
  }
});

// Notification Modal Elements
const OpenNtfModalBtn = document.querySelector(".n-m-btn")
const NtfModal = document.querySelector(".n-m-box")
const toggleNftModal = () => {
  NtfModal.classList.toggle("show-modal");
};
// OPEN Notification Modal BOX after 2000ms Close the Modal
OpenNtfModalBtn.addEventListener("click", () => {
  toggleNftModal();
  setTimeout(function(){
    toggleNftModal();
  },2000);
});

// Order Modal Elements
const OpenOrdModalBtn = document.querySelector(".o-m-btn")
const CloseOrdModalBtn = document.querySelector(".modal-btn")
const OrdModal = document.querySelector(".order-modal-backdrop")
const toggleOrdModal = () => {
  OrdModal.classList.toggle("show-modal");
};
// OPEN Delete MODAL BOX
OpenOrdModalBtn.addEventListener("click", () => {
  toggleOrdModal();
});

// CLOSE Delete MODAL BOX
CloseOrdModalBtn.addEventListener("click", () => {
  toggleOrdModal();
});

