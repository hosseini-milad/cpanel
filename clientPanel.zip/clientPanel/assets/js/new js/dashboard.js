const DashCard = document.querySelectorAll(".dash-card")
const Rx = document.querySelector(".rx-details")
const Stock = document.querySelector(".stock-details")
const Frame = document.querySelector(".frame-details")
const Scrap = document.querySelector(".scrap-details")

DashCard.forEach((e) => {
  const CurrentClassList = e.classList
  e.addEventListener("click" , () => {
    if(CurrentClassList.contains("rx-card")){
      Rx.classList.toggle("display-on")
      Stock.classList.remove("display-on")
      Frame.classList.remove("display-on")
      Scrap.classList.remove("display-on")
    }
    if(CurrentClassList.contains("stock-card")){
      Rx.classList.remove("display-on")
      Stock.classList.toggle("display-on")
      Frame.classList.remove("display-on")
      Scrap.classList.remove("display-on")
    }
    if(CurrentClassList.contains("frame-card")){
      Rx.classList.remove("display-on")
      Stock.classList.remove("display-on")
      Frame.classList.toggle("display-on")
      Scrap.classList.remove("display-on")
    }
    if(CurrentClassList.contains("scrap-card")){
        Rx.classList.remove("display-on")
      Stock.classList.remove("display-on")
      Frame.classList.remove("display-on")
      Scrap.classList.toggle("display-on")
    }
    
  })
})


const SidebarBtn = document.querySelector(".sidebar-btn")
const Sidebar = document.querySelector(".sidebar-container")
const Navbar = document.querySelector(".navbar-container")
const FlipBtn = document.querySelectorAll(".flip-btn")
const DashContainer = document.querySelector(".dashboard-container")


SidebarBtn.addEventListener("click" , ()=>{
  Sidebar.classList.toggle("active")
})

FlipBtn.forEach((e)=>{
  e.addEventListener("click" , ()=>{
    Sidebar.classList.toggle("display-on")
    Navbar.classList.toggle("display-on")

    if(Sidebar.classList.contains("display-on")){
      DashContainer.classList.add("sidebar")
      DashContainer.classList.remove("topbar")
      SidebarBtn.classList.add("display-on")
    }
    if(Navbar.classList.contains("display-on")){
      DashContainer.classList.add("topbar")
      DashContainer.classList.remove("sidebar")
      SidebarBtn.classList.remove("display-on")
    }
  })
  
})





const DashTabBtn = document.querySelector(".dash-tab-btn")
const StartTabBtn = document.querySelector(".start-tab-btn")
const NotifTabBtn = document.querySelector(".notif-tab-btn")
const UpdateTabBtn = document.querySelector(".update-tab-btn")
const Dashboard = document.querySelector(".dash-tab")
const GetStart = document.querySelector(".start-dash")
const Notif = document.querySelector(".notif-dash")
const Update = document.querySelector(".update-dash")


DashTabBtn.addEventListener("click" , ()=>{
  DashTabBtn.classList.add("active-tab")
  StartTabBtn.classList.remove("active-tab")
  NotifTabBtn.classList.remove("active-tab")
  Dashboard.classList.add("display-on")
  GetStart.classList.remove("display-on")
  Notif.classList.remove("display-on")
  Update.classList.remove("display-on")



})
StartTabBtn.addEventListener("click" , ()=>{
  StartTabBtn.classList.add("active-tab")
  DashTabBtn.classList.remove("active-tab")
  NotifTabBtn.classList.remove("active-tab")
  Dashboard.classList.remove("display-on")
  GetStart.classList.add("display-on")
  Notif.classList.remove("display-on")
  Update.classList.remove("display-on")

})
NotifTabBtn.addEventListener("click" , ()=>{
  NotifTabBtn.classList.add("active-tab")
  StartTabBtn.classList.remove("active-tab")
  DashTabBtn.classList.remove("active-tab")
  Dashboard.classList.remove("display-on")
  GetStart.classList.remove("display-on")
  Notif.classList.add("display-on")
  Update.classList.remove("display-on")

})
UpdateTabBtn.addEventListener("click" , ()=>{
  UpdateTabBtn.classList.add("active-tab")
  NotifTabBtn.classList.remove("active-tab")
  StartTabBtn.classList.remove("active-tab")
  DashTabBtn.classList.remove("active-tab")
  Dashboard.classList.remove("display-on")
  GetStart.classList.remove("display-on")
  Notif.classList.remove("display-on")
  Update.classList.add("display-on")
})

