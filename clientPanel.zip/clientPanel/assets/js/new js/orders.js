const DotBtn = document.querySelector(".dot-btn")
const SubMenu = document.querySelector(".option-sub")
DotBtn.addEventListener("click" , ()=>{
  SubMenu.classList.toggle("display-on")
})
const ExtendBtn = document.querySelector(".extend-btn")
const ExtendMenu = document.querySelector(".sub-order")
ExtendBtn.addEventListener("click" , ()=>{
  ExtendMenu.classList.toggle("display-table")
})
