const ListBtn = document.querySelector(".list-btn")
const TileBtn = document.querySelector(".tile-btn")
const ListFilter = document.querySelector(".list-filter-wrapper")
const TileFilter = document.querySelector(".tile-filter-wrapper")
const FilterTiles = document.querySelectorAll(".filter-tile")
const MainFilterTiles = document.querySelectorAll(".main-filter-btn")
const OilBtn = document.querySelector(".oil-btn")
const LubBtn = document.querySelector(".lub-btn")
const AccBtn = document.querySelector(".acc-btn")
const LubeFilters = document.querySelectorAll(".lub-filter")
const AccFilters = document.querySelectorAll(".acc-filter")
const ProductSec = document.querySelector(".product-sec")
const TableSec = document.querySelector(".product-table-sec")
const BuyBtn = document.querySelectorAll(".buy-btn")
const PerUnit = document.querySelector(".percent-unit")
const PriUnit = document.querySelector(".price-unit")
const TempBtn = document.querySelector(".temp-btn")
const HurryBtn = document.querySelector(".hurry-btn")
const OrderTitle = document.querySelector(".order-title")
const CashPay = document.querySelector(".cash-pay")
const CheckPay = document.querySelector(".check-pay")
const FastOrder = document.querySelector(".fast-order")
const SlowOrder = document.querySelector(".slow-order")
const DropDownMenu = document.querySelector(".code-drop-menu")
const DropDownBtn = document.querySelector(".dp-input")
const Ads = document.querySelector(".add-wrapper")
const CuInput = document.querySelector(".f-customer")
const CuDropDown = document.querySelector(".f-customer-dropdpwn")




FilterTiles.forEach((e)=>{
  e.addEventListener("click" , ()=>{
    e.classList.toggle("tile-active")
  })
})

MainFilterTiles.forEach((e)=>{
  e.addEventListener("click" , ()=>{
    if(e.classList.contains("oil-btn")){
      ProductSec.classList.toggle("display-on")
    }
    if(e.classList.contains("lub-btn")){
      LubeFilters.forEach((e)=>e.classList.toggle("display-on"))
    }
    if(e.classList.contains("acc-btn")){
      AccFilters.forEach((e)=>e.classList.toggle("display-on"))
    }
  })})

AccFilters.forEach(e => {
  e.addEventListener("click" , ()=>{
    ProductSec.classList.toggle("display-on")
  })
})
LubeFilters.forEach(e => {
  e.addEventListener("click" , ()=>{
    ProductSec.classList.toggle("display-on")
  })
})

BuyBtn.forEach(e =>{
  e.addEventListener("click" , ()=>{
    TableSec.classList.toggle("display-on")
  })
})
TempBtn.addEventListener("click" , ()=>{
  TableSec.classList.add("display-on")
})


PerUnit.addEventListener("click" , (e)=>{
  PerUnit.classList.toggle("off-unit");
  PriUnit.classList.toggle("off-unit");
  
})
PriUnit.addEventListener("click" , (e)=>{
  PriUnit.classList.toggle("off-unit");
  PerUnit.classList.toggle("off-unit");
  
})

OrderTitle.addEventListener("click" , ()=>{
  TableSec.classList.toggle("height-on");
  
  
})


CashPay.addEventListener("click" , (e)=>{
  CashPay.classList.toggle("display-on");
  CheckPay.classList.toggle("display-on");
  
})
CheckPay.addEventListener("click" , (e)=>{
  CheckPay.classList.toggle("display-on");
  CashPay.classList.toggle("display-on");
  
})
FastOrder.addEventListener("click" , (e)=>{
  FastOrder.classList.toggle("display-on");
  SlowOrder.classList.toggle("display-on");
  
})
SlowOrder.addEventListener("click" , (e)=>{
  SlowOrder.classList.toggle("display-on");
  FastOrder.classList.toggle("display-on");
  
})
ListBtn.addEventListener("click" , ()=>{
  ListBtn.classList.add("view-active")
  TileBtn.classList.remove("view-active")
  TileFilter.classList.remove("display-on")
  Ads.classList.remove("display-on")
  ListFilter.classList.add("display-on")

  
  
})
TileBtn.addEventListener("click" , ()=>{
  ListBtn.classList.remove("view-active")
  TileBtn.classList.add("view-active")
  TileFilter.classList.add("display-on")
  ListFilter.classList.remove("display-on")
  Ads.classList.add("display-on")

})

DropDownBtn.addEventListener("click" , ()=>{
  DropDownMenu.classList.toggle("display-on");
  
})
CuInput.addEventListener("click" , ()=>{
  CuDropDown.classList.toggle("display-on");
  
})
